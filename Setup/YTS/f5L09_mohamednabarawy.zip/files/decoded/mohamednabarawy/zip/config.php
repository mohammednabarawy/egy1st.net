<?php
/*
 * @ https://EasyToYou.eu - IonCube v10 Decoder Online
 * @ PHP 5.6
 * @ Decoder version: 1.0.3
 * @ Release: 10.12.2019
 *
 * @ ZendGuard Decoder PHP 5.6
 */

$Config["name"] = "إعدادات القالب";
$Config["nameEN"] = "Theme settings";
$Config["roles"] = "administrator";
$Config["switch"] = true;
$Config["mobile"] = true;

?>